
public interface Validate {
	public boolean getUserName(String username,String password,String givenUsername,String givenPassword);
}