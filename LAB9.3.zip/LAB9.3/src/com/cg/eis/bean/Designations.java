package com.cg.eis.bean;
public enum Designations {
	SystemAssociate,Programmer,Manager,Clerk
}
