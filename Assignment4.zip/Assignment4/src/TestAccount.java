
public class TestAccount 
{

	public static void main(String[] args) throws OverDraftLimitException 
	{
		Person smith=new Person();
		Person kathy=new Person();
		Account smithAccount=new Account();
		Account kathyAccount=new Account();
		long accnum=(long)(Math.random()*200);
		smith.setName("Smith");
		smith.setAge(22);
		smithAccount.setAccNum(accnum);
		smithAccount.setAccHolder(smith);
		smithAccount.deposit(2000);
		System.out.println(smithAccount.toString());
		accnum=(long)(Math.random()*100);
		kathy.setName("Kathy");
		kathy.setAge(26);
		kathyAccount.setAccNum(accnum);
		kathyAccount.setAccHolder(kathy);
		try{
			kathyAccount.withdraw(2000);
		}
		catch(InsufficientBalanceException e)
		{System.out.println("Insufficient Balance ");}
		
		
		System.out.println(kathyAccount.toString());
		//Person per=new Person("Kathy",23);
		//Account account=new Account();
		
	}

}
