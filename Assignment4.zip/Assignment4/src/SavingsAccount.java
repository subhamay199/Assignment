public class SavingsAccount extends Account
{
	final double minimumBalance=500;
	public SavingsAccount(long accNum,double balance,double amount)
	{
		this.accNum=accNum;
		this.balance=balance;
	}
	
	 public void withdraw(double amt)
		{
		 if(balance-amt>500)
			balance-=amt;
		 else
			 System.out.println("Balance Can't Be Withdrawn");
		}
}
