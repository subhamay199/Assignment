
public class OverDraftLimitException extends Exception
{
	public OverDraftLimitException()
	{
		System.out.println("OverDraft Limit Exceeded");
	}
}
