public interface FunctionInterface {
	String space(String x);
	}