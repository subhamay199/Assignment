--1-------------------------------------------------------------------
create table customer (customerid number(5),cust_name varchar2(20),
address1 varchar2(30),address2 varchar2(30))
--2--------------------------------------------------------------------
alter table customer modify cust_name varchar(30) not null;

alter table customer rename column  cust_name to customername
--3--------------------------------------------------------------------
alter table customer add (gender varchar2(1),age number(3),
phoneno number(10))

alter table customer rename to cust_table
--4--------------------------------------------------------------------
insert into cust_table values
(1000, 'Allen', '#115 Chicago', '#115 Chicago', 'M', 25, 7878776)

insert into cust_table values
(1001, 'George','#116 France', '#116 France', 'M', 25, 434524)

insert into cust_table values
(1002, 'Becker','#114 New York', '#114 New York', 'M', 45, 431525)
--5--------------------------------------------------------------------
alter table cust_table add constraint
custid_prim primary key(customerid)
--6--------------------------------------------------------------------
insert into cust_table values
(1002, 'John', '#114 Chicago', '#114 Chicago', 'M', 45, 439525)
--7--------------------------------------------------------------------
alter table cust_table disable constraint custid_prim

insert into cust_table values
(1002, 'Becker', '#114 New York', '#114 New york' , 'M', 45, 431525)

insert into cust_table values
(1003, 'Nanapatekar', '#115 India', '#115 India' , 'M', 45, 431525)
--8--------------------------------------------------------------------
alter table cust_table enable constraint custid_prim
--9--------------------------------------------------------------------
alter table cust_table drop constraint custid_prim

insert into cust_table values
(1002, 'Becker', '#114 New York', '#114 New york' , 'M', 45, 431525)

insert into cust_table values
(1003, 'Nanapatekar', '#115 India', '#115 India' , 'M', 45, 431525)
--10--------------------------------------------------------------------
truncate table cust_table
--11--------------------------------------------------------------------
alter table cust_table add e_mail varchar2(20)
--12--------------------------------------------------------------------
alter table cust_table drop column e_mail
--13---------------------------------------------------------------------
create table suppliers (suppid number(5),sname varchar2(20),
addr1 varchar2(30),addr2 varchar2(30),contactno number(10))
--14---------------------------------------------------------------------
drop table cust_table

create table customermaster (customerid number(5) constraint 
custid_pk primary key,customername varchar2(30) not null,
address1 varchar2(30) not null,address2 varchar2(30),
gender varchar2(1),age number(3),phoneno number(10))
--15---------------------------------------------------------------------
create table accountsmaster (customerid number(5),
accountnumber number(10,2) constraint acc_pk primary key,
accounttype char(3),ledgerbalance number(10,2) not null)
--16---------------------------------------------------------------------
alter table accountsmaster add constraint cust_acc 
foreign key(customerid) references customermaster(customerid)
--17-------------------------------------------------------------------
insert into customermaster values
(1000, 'Allen', '#115 Chicago', '#115 Chicago', 'M', 25, 7878776)

insert into customermaster values
(1001, 'George', '#116 France', '#116 France', 'M', 25, 434524)

insert into customermaster values
(1002, 'Becker', '#114 New York', '#114 New York', 'M', 45, 431525)
--18---------------------------------------------------------------------
alter table accountsmaster add constraint chk_acctype 
check (accounttype='nri' or accounttype='ind')
--19---------------------------------------------------------------------
alter table accountsmaster add constraint balance_check 
check (ledgerbalance>5000)
--20---------------------------------------------------------------------
ALTER table accountsmaster drop constraint cust_acc1;
 
ALTER table accountsmaster ADD constraint cust_acc1 FOREIGN KEY (CustomerId) references customermaster (Customerid) ON DELETE CASCADE;

--21---------------------------------------------------------------------
select * into accountdetails from accountsmaster //notworking
--22---------------------------------------------------------------------
CREATE VIEW Acc_view (CustomerCode,AccountNumber, Type, Balance) AS Select * FROM AccountsMaster;
SELECT * FROM Acc_view;
--23---------------------------------------------------------------------
CREATE VIEW vAccs_dtls (CustomerCode) AS SELECT Customerid FROM AccountsMaster WHERE Accounttype='IND' AND  LEDGERBALANCE>10000 WITH CHECK OPTION;
select * from vAccs_dtls;
--24---------------------------------------------------------------------
CREATE VIEW accsvw10 AS SELECT * FROM Accountsmaster with READ ONLY;
--25---------------------------------------------------------------------
create sequence seq_dept
start with 40
increment by 10
minvalue 0
maxvalue 200 
cycle

update department_master set deptno = seq_dept.nextval
--26---------------------------------------------------------------------
insert into department_master values(seq_dept.nextval,'IT')
insert into department_master values(seq_dept.nextval,'LnD')
--27---------------------------------------------------------------------
drop sequence seq_dept
--28---------------------------------------------------------------------
select index_type, table_owner, table_name from user_indexes where index_name='NO_NAME';
--29---------------------------------------------------------------------
create or replace synonym synemp for emp
--30---------------------------------------------------------------------
CREATE SYNONYM synEmp for emp;
select * from synEmp;
--31---------------------------------------------------------------------
create index idx_emp_hiredate on emp(hiredate)
--32---------------------------------------------------------------------
create sequence seq_emp
start with 1001
increment by 1
minvalue 950
maxvalue  1100
cycle

update emp set empno=seq_emp.nextval
-----------------------------------------------------------------------