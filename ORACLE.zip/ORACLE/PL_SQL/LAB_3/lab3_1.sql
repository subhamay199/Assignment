CREATE OR REPLACE FUNCTION Age(Birthdate in Date)
RETURN NUMBER IS
age_in_years Number(20);
 BEGIN
age_in_years:=ROUND(months_between(SYSDATE,Birthdate)/12);
RETURN age_in_years;
 EXCEPTION
WHEN OTHERS THEN
RETURN 0;
END;
 /
--MAIN PL/SQL BLOCK
DECLARE
D_DATE DATE;
BEGIN
D_DATE:=to_date(�&date�,�DD-MM-YYYY�);
Dbms_output.put_line(�Your age is �||� �||Age(D_DATE));
END;
/
