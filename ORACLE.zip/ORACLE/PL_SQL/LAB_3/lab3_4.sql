CREATE OR REPLACE PROCEDURE Update_Salary(Staff_ID NUMBER) IS
 Exp NUMBER;
 Increment NUMBER;
Salary NUMBER;
BEGIN
SELECT round(months_between(SYSDATE,HIREDATE)/12),Staff_Sal INTO Exp,Salary FROM Staff_Master WHERE STaff_Code=Staff_ID;
IF Exp < 2 THEN
Increment:=0;
ELSIF (Exp > 2 AND Exp < 5) THEN
Increment:=0.20*Salary;
 ELSE
 Increment:=0.25*Salary;
 END IF;
INSERT INTO Staff_Master_Back
 SELECT * FROM Staff_Master WHERE Staff_Code=Staff_ID;
UPDATE Staff_Master
SET STaff_Sal=Staff_Sal+Increment
WHERE Staff_Code = Staff_ID;
 COMMIT;
EXCEPTION
WHEN NO_DATA_FOUND THEN
 DBMS_OUTPUT.PUT_LINE('No Record Found');
 END;
/


DECLARE
S_CODE STAFF_MASTER.STAFF_CODE%TYPE;
BEGIN
S_CODE:=&STAFF_CODE;
Update_Salary(S_CODE);
END;
/
