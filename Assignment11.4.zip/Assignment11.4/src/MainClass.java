import java.util.function.BiFunction;
public class MainClass {  
public static void main(String[] args) {  
BiFunction<Integer, Integer, Integer>adder = Arithmetics::add;  
int result = adder.apply(10, 20);  
System.out.println(result);  
}  
}  