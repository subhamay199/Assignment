
public class Arithmetics {
		public static int add(int a, int b){  
		return a+b;  
		}  
}
